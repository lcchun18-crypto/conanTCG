// 名探偵コナン TCG 룰 엔진 서버 (서버가 룰을 판정하고, 카드 효과는 엔진이 전부 자동으로 처리)
const http = require('http'), fs = require('fs'), path = require('path');
const rooms = {}; let nid = 1;
const send = (w, o) => w && w.readyState === 1 && w.send(JSON.stringify(o));
// v1.9.0: 사람 vs 사람 방은 방마다 난수 상태(R.rng, mulberry32)를 가진다 → '이번 턴 다시시작' 이 같은 난수 흐름을 복원한다. R.rng 가 없으면 예전처럼 Math.random.
let CUR = null;
const rnd = () => { const R = CUR; if (!R || R.rng == null) return Math.random(); let t = (R.rng = (R.rng + 0x6D2B79F5) >>> 0); t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const withCur = (R, f) => { const prev = CUR; CUR = R; try { return f(); } finally { CUR = prev; } };
const shuf = a => { for (let i = a.length - 1; i > 0; i--) { const j = rnd() * (i + 1) | 0; [a[i], a[j]] = [a[j], a[i]]; } };
const cl = (x, n = 2000) => String(x || '').slice(0, n);
const nm = s => s ? '게스트' : '호스트';
const mkP = () => ({ deck: [], hand: [], file: [], evid: [], rem: [], field: [], partner: null, pIn: false, kase: null, ready: false, pa: [], tr: false });
const mkR = code => ({ code, ws: [null, null], defs: {}, cards: {}, q: [], eff: null, ending: 0, P: [mkP(), mkP()], phase: 'setup', turn: 0, first: 0, n: 0, fl: {}, sub: null, tt: [[], []], actor: null, log: ['방이 만들어졌습니다.'] });
// v1.17.0: 로그 줄에 나온 카드 이름의 위치와 카드(정의) 키를 함께 저장한다. 이름으로 카드를 추측하지 않고, 로그를 만드는 쪽이 D.cn(R, 카드ID) 로 이름을 넣을 때 그 카드의 정의 키(R.cards[id].d)를 기록 → 같은 이름의 다른 카드도 정확히 구분
const say = (R, t) => { R.log.push(t); const p = R._lp; if (!p) return; R._lp = null; const refs = []; let cur = 0; for (const r of p) { const i = t.indexOf(r.n, cur); if (i < 0) continue; refs.push([i, i + r.n.length, r.d]); cur = i + r.n.length; } if (refs.length) (R.lr || (R.lr = {}))[R.log.length - 1] = refs; };
const D = (R, id) => R.defs[R.cards[id].d];
D.nms = (R, ids) => (ids || []).map(x => D.cn(R, x)).join(', ');   // v1.17.2: 공개 영역으로 나온 카드 여러 장의 이름 목록(로그용, 각 이름은 hover 링크 예약). 비공개 정보에는 쓰지 말 것
D.cn = (R, id) => { const c = R.cards[id], n = D(R, id).n; (R._lp || (R._lp = [])).push({ n, d: c.d }); return n; };   // say(R, `…${D.cn(R, id)}…`) 에서만 사용: 이름 문자열을 돌려주면서 로그 링크용 (이름, 정의 키) 를 예약
const tok = d => { const k = String(d.kw || '').toLowerCase(), n = re => { const m = re.exec(k); return m ? +m[1] : 0; };
  return { rapid: /rapid/.test(k), asC: /assault(?!-case)/.test(k), asE: /assault(?!-char)/.test(k), bullet: /bullet/.test(k),
    dis: /disguise/.test(k), mis: n(/misread\s*[:=]?\s*(\d+)/), cut: n(/cutin\s*[:=]?\s*(\d+)/) }; };
const ap = (R, id) => (R.cards[id].bAp != null ? R.cards[id].bAp : (+D(R, id).ap || 0)) + (R.cards[id].apm || 0) + (R.cards[id].cm || 0) + FX.stat(R, id).ap;
const lpOf = (R, id) => (R.cards[id].bLp != null ? R.cards[id].bLp : (+D(R, id).lp || 0)) + (R.cards[id].lpm || 0) + FX.stat(R, id).lp;
const tk = (R, id) => { let kw = (R.cards[id].blank ? '' : (D(R, id).kw || '')) + ' ' + (R.cards[id].tkw || '') + FX.stat(R, id).kw; for (const w of String(R.cards[id].lose || '').split(/\s+/).filter(Boolean)) kw = kw.replace(new RegExp(w + '\\s*[:=]?\\s*\\d*', 'ig'), ' '); return tok({ kw }); };
const cols = d => String(d.color || '').toLowerCase().split(/[\/,&\s]+/).filter(Boolean);
const okc = (R, s, d, id) => { if (id != null && FX.ignoreColor(R, s, id)) return true; const cc = cols(D(R, R.P[s].kase)); return cols(d).every(x => cc.includes(x)); };
const fcount = (R, s) => R.P[s].file.length + (R.P[s].pIn ? 1 : 0);
const FX = require('./fx')({ contact: (R, a, d) => contact(R, a, d), okc: (R, s, d, id) => okc(R, s, d, id), win: (R, s, why) => win(R, s, why), D, say, shuf, pull, chk, gain, nm, fcount, cols, ap: (R, id) => ap(R, id), lpOf: (R, id) => lpOf(R, id) });
const win = (R, s, why) => { if (R.phase === 'over') return; [...R.q, ...(R.eff ? [R.eff.it] : [])].forEach(it => { if (it.kind === 'flash' || it.kind === 'event') R.P[it.s].rem.push(it.src); }); // 처리 중이던 카드는 리무브 에리어로
  R.phase = 'over'; R.winner = s; R.sub = null; R.eff = null; R.q = []; say(R, `🏆 ${nm(s)} 승리 — ${why}`); };

// 덱: 배열 끝이 맨 위
const top = (R, s) => R.P[s].deck.pop();
function chk(R, s) { const P = R.P[s]; if (R.phase !== 'play' || P.deck.length) return;
  if (!P.rem.length) return win(R, 1 - s, `${nm(s)} 리프레시 불가(리무브 에리어 0장)`);
  const old = P.rem; P.deck = P.rem; P.rem = []; shuf(P.deck); R.P[1 - s].tr = true; if (FX.pk(R, s, 'norefresh')) say(R, `${nm(s)} 리프레시! (카드 효과로 상대는 증거를 얻지 못함)`); else { say(R, `${nm(s)} 리프레시! 상대가 증거 1장 획득`); gain(R, 1 - s, 1); } FX.remLeft(R, s, old); }
function pull(R, s) { if (!R.P[s].deck.length) return null; const x = top(R, s); chk(R, s); return x; }
function gain(R, s, n, cx) { let got = 0; for (let i = 0; i < n && R.phase === 'play'; i++) { const x = pull(R, s); if (x != null) { R.cards[x].up = false; R.P[s].evid.push(x); got++; } } if (got) FX.bus(R, 'evgain', { s, by: 'effect', ...(cx || {}) }); }
const rmChar = (R, s, id, why, killer) => FX.rmChar(R, id, why, killer);

function startTurn(R) { const s = R.turn, P = R.P[s]; R.n++; R.fl = {}; R.actor = null; R.step = 'main'; Object.values(R.cards).forEach(c => { c.u = {}; });
  P.pIn = false; R.cards[P.partner].st = 'a';
  P.field.forEach(id => { const c = R.cards[id]; if (FX.hasKwTk(R, id, 'noauto')) return; if (c.hold != null) { if (R.P[R.cards[c.hold] ? R.cards[c.hold].o : 0].field.includes(c.hold)) return; c.hold = null; } c.st = c.st === 'x' ? 's' : 'a'; }); // 스턴은 액티브 대신 슬립(noauto 키워드는 오토 페이즈에 상태가 바뀌지 않음)
  let x = pull(R, s); if (x != null) P.hand.push(x);
  for (let i = 0; i < (R.n === 1 ? 1 : 2) && R.phase === 'play'; i++) { x = pull(R, s); if (x != null) { R.cards[x].up = false; P.file.push(x); } }
  say(R, `── ${nm(s)}의 턴 (#${R.n}) ──`); FX.fireMain(R, s); if (R.rng != null) snapTake(R); }

// ── v1.9.0 이번 턴 다시시작: 턴 시작 처리(오토/드로우/FILE) 직후의 정규(canonical) 상태를 서버가 보관하고, 복원은 그 스냅샷 자체를 되돌린다(드로우 재실행 아님). 난수 상태(R.rng)도 함께 저장.
const SNAP_SKIP = new Set(['ws', 'tok', 'gt', 'bot', 'defs', 'code', 'log', 'lr', '_lp', 'rv', 'rvSeq', 'rvLog', 'snap', 'curS', '_dp', 'spec', 'noSpec']);
const _prot = new WeakMap();
const protSet = R => { const n = Object.keys(R.defs).length, c = _prot.get(R.defs); if (c && c.n === n) return c.set; const set = new WeakSet(), st = [R.defs]; while (st.length) { const v = st.pop(); if (!v || typeof v !== 'object' || set.has(v)) continue; set.add(v); Object.values(v).forEach(x => st.push(x)); } _prot.set(R.defs, { n, set }); return set; };
const dclone = (v, prot) => { if (!v || typeof v !== 'object') return v; if (prot.has(v)) return v; if (Array.isArray(v)) return v.map(x => dclone(x, prot));
  if (v instanceof Set) return new Set([...v].map(x => dclone(x, prot))); if (v instanceof Map) return new Map([...v].map(([k, x]) => [k, dclone(x, prot)]));
  const p = Object.getPrototypeOf(v); if (p !== Object.prototype && p !== null) return v; const o = {}; for (const k of Object.keys(v)) o[k] = dclone(v[k], prot); return o; };
function snapTake(R) { if (R.bot || R.phase !== 'play') { R.snap = null; return; } const prot = protSet(R), data = {};
  for (const k of Object.keys(R)) { if (SNAP_SKIP.has(k)) continue; data[k] = k === 'q' ? R.q.map(it => ({ ...it })) : dclone(R[k], prot); }
  R.snap = { turn: R.turn, n: R.n, data }; }
function turnRestart(R, seat) {
  if (R.bot) return '봇 대전에서는 사용할 수 없습니다'; if (R.phase !== 'play') return '진행 중인 게임에서만 사용할 수 있습니다'; if (R.turn !== seat) return '내 턴에서만 사용할 수 있습니다';
  const S = R.snap; if (!S || S.n !== R.n || S.turn !== R.turn) return '복원할 턴 시작 상태가 없습니다';
  const prot = protSet(R); for (const k of Object.keys(R)) if (!SNAP_SKIP.has(k) && !(k in S.data)) delete R[k];
  for (const [k, v] of Object.entries(S.data)) R[k] = k === 'q' ? v.map(it => ({ ...it })) : dclone(v, prot);   // 스냅샷은 그대로 두고 복사본을 적용 → 같은 턴에 여러 번 눌러도 항상 원래 턴 시작 상태
  R.rv = []; say(R, `↩ ${nm(seat)}이(가) 이번 턴을 다시 시작했습니다 (턴 시작 상태로 복원)`);
  withCur(R, () => { FX.pump(R); settle(R); if (R.ending && !R.eff && !R.q.length && !R.sub && R.phase === 'play') { doEnd(R); FX.pump(R); settle(R); } }); return null; }
// ── v1.9.0 다시하기: 같은 방 코드·연결을 유지한 채 게임 상태 전체를 처음(덱 등록 전)으로 되돌린다. 이전 덱은 재사용하지 않는다.
function resetRoom(R, seat) { const keep = { code: R.code, ws: R.ws, tok: R.tok, gt: R.gt, spec: R.spec, noSpec: R.noSpec }; for (const k of Object.keys(R)) delete R[k];
  Object.assign(R, mkR(keep.code)); R.ws = keep.ws; if (keep.tok) R.tok = keep.tok; if (keep.gt) R.gt = keep.gt; if (keep.spec) R.spec = keep.spec; if (keep.noSpec) R.noSpec = true; R.rng = (Math.random() * 4294967296) >>> 0;
  R.lr = null; R._lp = null; R.log = [seat === 0 || seat === 1 ? `${nm(seat)}이(가) 게임을 초기화했습니다. 두 플레이어 모두 덱을 다시 등록하세요.` : '게임이 초기화되었습니다.']; return R; }

function start(R) { R.chooser = undefined;
  R.P.forEach(P => { shuf(P.deck); for (let i = 0; i < 5; i++) P.hand.push(P.deck.pop()); });
  // v1.17.33: 유저끼리(봇 아님)는 둘 중 한 명이 랜덤으로 '선후공 결정권'을 얻고, 그 사람이 선공/후공을 고른다
  if (process.env.FIRST_CHOOSE !== '0' && R.ws[0] && R.ws[1] && !R.bot && R.firstPref !== 0 && R.firstPref !== 1) { R.phase = 'choose'; R.first = undefined; R.mullSeat = undefined; R.chooser = Math.random() < .5 ? 0 : 1; say(R, `🎲 추첨 결과: ${nm(R.chooser)}이(가) 선공/후공을 정합니다.`);
    // 무응답(자리 비움/오래된 화면 파일 등)으로 멈추지 않도록 일정 시간 뒤 자동으로 랜덤 결정
    clearTimeout(R.chooseT); R.chooseT = setTimeout(() => { if (R.phase !== 'choose') return; R.first = Math.random() < .5 ? 0 : 1; say(R, `⏱ 시간 초과 — 자동으로 ${nm(R.first)} 선공으로 정했습니다.`); beginMull(R); try { bc(R); } catch (e) {} }, +process.env.CHOOSE_MS || 45000); R.chooseT.unref && R.chooseT.unref(); return; }
  R.first = R.firstPref === 0 || R.firstPref === 1 ? R.firstPref : Math.random() < .5 ? 0 : 1; beginMull(R); }
function beginMull(R) { clearTimeout(R.chooseT); R.phase = 'mull'; R.mullSeat = R.first; say(R, `선공: ${nm(R.first)}. 손패 교체(멀리건)는 1회 가능합니다.`); }

// v1.14.0: 카드 이미지는 파일(CardImage/<파일명>) — 클라이언트가 보내는 img 는 '우리 서버의 CardImage 상대 경로'만 받는다(다른 사이트 URL·경로 이탈 차단). 옛 data URL 은 호환용으로만 허용.
const IMG_REL = /^CardImage(?:Web)?\/[A-Za-z0-9][A-Za-z0-9_.-]{0,118}\.(jpg|jpeg|png|webp)$/i;
function cleanImg(v) { v = String(v || ''); if (IMG_REL.test(v) && !v.includes('..')) return v; return v.startsWith('data:image/') ? v.slice(0, 200000) : ''; }
function ready(R, s, m) {
  if (R.phase !== 'setup') return '이미 게임이 시작되었습니다';
  const defs = {}, P = R.P[s], T = ['partner', 'char', 'event', 'case'];
  Object.entries(m.defs || {}).slice(0, 300).forEach(([id, d]) => { defs[id] = R.defs[s + ':' + id] = {
    n: cl(d.n, 80), type: T.includes(d.type) ? d.type : 'char', color: cl(d.color, 30), lv: cl(d.lv, 4), lv2: cl(d.lv2, 4), ap: cl(d.ap, 8),
    lp: cl(d.lp, 4), kw: cl(d.kw, 100), trait: cl(d.trait, 100), ab: FX.cleanAb(typeof d.ab === 'string' ? (() => { try { return JSON.parse(d.ab); } catch { return []; } })() : d.ab), fx: cl(d.fx), extra: cl(d.extra), img: cleanImg(d.img) }; });
  const L = m.list || [];
  if (L.length !== 40) return `덱은 정확히 40장이어야 합니다 (현재 ${L.length}장)`;
  for (const id of L) { const d = defs[id]; if (!d || !['char', 'event'].includes(d.type)) return '덱에는 캐릭터/이벤트 카드만 넣을 수 있습니다'; }
  const cc = {}; for (const id of L) { cc[id] = (cc[id] || 0) + 1; if (cc[id] > 3 && !(defs[id].ab || []).some(a => a.ic === 'deckfree')) return `같은 카드는 최대 3장 (${defs[id].n})`; }
  if (!defs[m.partner] || defs[m.partner].type !== 'partner') return '파트너 카드를 선택하세요';
  if (!defs[m.kase] || defs[m.kase].type !== 'case') return '사건 카드를 선택하세요';
  Object.values(R.cards).filter(c => c.o === s).forEach(c => delete R.cards[c.id]);
  const mkc = id => { const i = nid++; R.cards[i] = { id: i, o: s, d: s + ':' + id, st: 'a' }; return i; };
  P.deck = L.map(mkc); P.partner = mkc(m.partner); P.kase = mkc(m.kase); P.ready = true;
  say(R, `${nm(s)} 덱 등록 완료`);
  if (R.P[0].ready && R.P[1].ready) start(R); }

function doReason(R, s, who, mis) { const P = R.P[s];
  let lp = (who === 'p' ? +D(R, P.partner).lp || 0 : lpOf(R, who)) - mis;
  say(R, `추리! 증거 ${lp}장` + (mis ? ` (미스리드 -${mis})` : '')); if (R.fl.nrg) { R.fl.nrg = 0; say(R, '[효과] 이 추리로 증거를 얻지 못함'); } else if (lp > 0) gain(R, s, lp,{ by: 'reason', ent: who === 'p' ? P.partner : who }); }

function contact(R, a, d) { const t = R.cards[a].o;
  const S = R.sub = { type: 'contact', atk: a, def: d, i: 0, pass: [], used: {} };
  S.order = ap(R, a) < ap(R, d) ? [t, 1 - t] : [1 - t, t]; S.who = S.order[0];
  FX.bus(R, 'contact', { s: R.cards[a].o, ent: a, tid: d }); FX.fire(R, 'oncontact', a, { k: 'atk', ent: d }); FX.fire(R, 'oncontact', d, { k: 'def', ent: a }); FX.fireAllyContact(R, R.cards[a].o, a); FX.fireAllyContact(R, R.cards[d].o, d);
  say(R, `컨택트! ${D.cn(R, a)}(AP ${ap(R, a)}) vs ${D.cn(R, d)}(AP ${ap(R, d)}) — ${nm(S.who)} 먼저 행동`); }
function endContact(R) { const S = R.sub, ao = R.cards[S.atk].o, dof = R.cards[S.def].o; R.sub = null;
  if (R.P[ao].field.includes(S.atk) && R.P[dof].field.includes(S.def)) { const A = ap(R, S.atk), B = ap(R, S.def);
    say(R, `AP 판정: ${A} vs ${B}`); if (A >= B && FX.hasKwTk(R, S.def, 'nrm-con')) say(R, `${D.cn(R, S.def)}: 이 컨택트로는 리무브되지 않음`); else if (A >= B) { if (FX.replaceAvail(R, S.def, ao, 'contact')) R.q.push({ kind: 'kill', s: ao, atk: S.atk, victim: S.def });
      else { rmChar(R, dof, S.def, 'contact', S.atk); say(R, '상대 캐릭터를 리무브!'); R.fl.kills = R.fl.kills || {}; R.fl.kills[S.atk] = true; FX.fire(R, 'onkill', S.atk, { by: 'contact', victim: S.def }); FX.fireAllyKill(R, ao, S.atk, S.def); } } else say(R, '아무 일도 일어나지 않음'); }
  R.fl.pkA = [{}, {}]; FX.bus(R, 'actend', { s: ao, ent: S.atk, k: 'char', tid: S.def });
  [S.atk, S.def].forEach(x => { if (R.cards[x]) { R.cards[x].cm = 0; R.cards[x].ckw = ''; } }); }
function cont(R, s, m) { const S = R.sub, P = R.P[s];
  if (m.a === 'pass') S.pass[S.i === 2 ? 0 : S.i] = 1;
  else if (m.a === 'cin' || m.a === 'dis') {
    if (S.used[s]) return '컨택트당 1회(1장)만 행동할 수 있습니다';
    const id = m.id; if (!P.hand.includes(id)) return '손패에 없는 카드';
    const d = D(R, id), t = tok(d), k = R.cards[S.atk].o === s ? 'atk' : 'def', my = S[k];
    if (m.a === 'cin') { if (FX.pk(R, 1 - s, 'nocutin')) return '카드 효과로 인해 컷인을 사용할 수 없습니다'; if (FX.hasKwTk(R, my, 'nocinself')) return '이 캐릭터의 컨택트 중에는 컷인을 사용할 수 없습니다'; if (!FX.cutOk(R, s, id, t.cut)) return '컷인을 가진 카드가 아니거나 지금은 사용할 수 없는 컷인입니다'; const v = FX.cutV(R, s, id, t.cut, my); R.cards[my].cm = (R.cards[my].cm || 0) + v;
      P.hand = P.hand.filter(x => x !== id); P.rem.push(id); say(R, `컷인! ${D.cn(R, id)} → AP+${v}`); FX.cutOps(R, s, id, my); FX.bus(R, 'cutin', { s, ent: id, tid: my, v }); }
    else { if (FX.pk(R, 1 - s, 'nodisguise')) return '카드 효과로 인해 변장을 사용할 수 없습니다'; if ((!t.dis && !FX.disAbs(R, id).length) || d.type !== 'char') return '변장을 가진 캐릭터가 아닙니다'; if (!FX.disguiseOk(R, s, id)) return '변장 조건(사건/FILE 등)을 만족하지 않습니다'; if (!P.field.includes(my)) return '컨택트 중인 내 캐릭터가 현장에 없어 변장할 수 없습니다'; const o = R.cards[my], n = R.cards[id]; const swLp = lpOf(R, my), swCols = cols(D(R, my));
      FX.release(R, my); P.field[P.field.indexOf(my)] = id; P.hand = P.hand.filter(x => x !== id);
      Object.assign(n, { st: o.st, apm: o.apm, cm: o.cm, lpm: o.lpm, sum: o.sum, tab: (o.tab || []).slice(), tkw: o.tkw || '', ckw: o.ckw || '' }); Object.assign(o, { st: 'a', apm: 0, cm: 0, lpm: 0, sum: 0, tab: [], tkw: '', ckw: '' });   // v1.17.31: 변장으로 교체되어도 이 턴 동안 부여된 능력/키워드(예: id_1156 의 「コンタクトでリムーブしたとき」)는 새 카드가 이어받는다
      if (FX.isMR(R, my) && R.turn !== s) { P.pa.push(my); say(R, `${D.cn(R, my)}: 상대 턴에 현장을 떠나 파트너 에리어로 이동`); } else P.deck.unshift(my); S[k] = id; say(R, `변장! ${D.cn(R, id)}(으)로 교체 (원래 캐릭터는 덱 아래)`); FX.mrEnter(R, s, id); if (!FX.pk(R, 1 - s, 'nodisev')) FX.fire(R, 'ondisguise', id, { swapped: my, swLp, swCols }); FX.bus(R, 'disguise', { s, ent: id, tid: id, swapped: my }); }
    S.used[s] = 1;
  } else return '컷인/변장/패스 중 선택하세요';
  S.i++; if (S.i === 2 && !(S.pass[0] && !S.pass[1])) S.i = 3;
  if (S.i >= 3) { S.fin = 1; return; } S.who = S.order[S.i === 2 ? 0 : S.i]; }
function guard(R, gid) { const S = R.sub, t = R.turn, O = R.P[1 - t];
  if (gid != null) return contact(R, S.atk, gid);
  if (S.tk === 'char') return contact(R, S.atk, S.tid);
  R.actor = S.atk; R.sub = null; const x = O.evid.pop(); if (x != null) { say(R, '사건 액션 성공: 상대 증거 1장 리무브'); const up = R.cards[x].up; R.cards[x].up = false;
    if ((D(R, x).ab || []).some(a => a.ic === 'flash' && !a.bang) && !FX.pk(R, t, 'noflash')) { FX.queueFlash(R, 1 - t, x); R.agp = { block: false }; } else O.rem.push(x); FX.bus(R, 'evrem', { s: 1 - t, by: 'action', ent: S.atk, cz: t }); }
  // 사건 액션의 증거 획득은 히라메키 처리가 끝난 뒤(「相手はこのアクションによって証拠を得られない」 가능)
  const fin = () => { const blk = R.agp && R.agp.block; R.agp = null; if (blk) say(R, '[효과] 이 액션으로 증거를 얻지 못함'); else gain(R, t, 1, { by: 'action', k: 'case', ent: S.atk }); R.fl.pkA = [{}, {}]; FX.bus(R, 'actend', { s: t, ent: S.atk, k: 'case' }); };
  if (R.agp) R.q.push({ kind: 'cb', s: t, last: true, fn: fin }); else fin(); }
function subact(R, s, m) { const S = R.sub, P = R.P[s];
  if (s !== S.who) return '상대의 응답을 기다리는 중입니다';
  if (S.type === 'mis') { if (m.a !== 'mis') return '미스리드를 선택하세요'; let t = 0;
    (m.ids || []).filter(x => S.ms.includes(x)).forEach(x => { R.cards[x].st = 's'; t += tk(R, x).mis; FX.bus(R, 'sleepEv', { s: R.cards[x].o, ent: x, by: 'mis' }); FX.bus(R, 'mis', { s: R.cards[x].o, ent: x, by: 'mis' }); });
    R.sub = null; return doReason(R, R.turn, S.rs, t); }
  if (S.type === 'guard') { if (m.a !== 'guard') return '가드 여부를 선택하세요';
    { const mg = mustGuard(R, s); if (mg.length && !mg.includes(m.id)) return '「必ずガードする」 능력을 가진 캐릭터로 반드시 가드해야 합니다'; }
    if (m.id != null) { const g = R.cards[m.id]; if (!g || !P.field.includes(m.id) || (g.st !== 'a' && !(g.st === 's' && FX.hasKwTk(R, m.id, 'sleepguard')))) return '액티브 캐릭터만 가드할 수 있습니다'; if (FX.hasKwTk(R, m.id, 'cantguard')) return '이 캐릭터는 가드할 수 없습니다'; g.st = 's'; say(R, '가드!'); FX.bus(R, 'sleepEv', { s, ent: m.id, by: 'action' }); FX.bus(R, 'guard', { s, ent: m.id, tid: S.atk, dst: S.tk === 'char' ? S.tid : undefined, k: S.tk }); }
    return guard(R, m.id); }
  return cont(R, s, m); }


function doEnd(R) { const s = R.turn; R.ending = 0; Object.values(R.cards).forEach(c => { c.apm = 0; c.lpm = 0; c.cm = 0; c.lvm = 0; c.tab = []; c.tkw = ''; c.sum = 0; c.blank = 0; }); R.tt = [[], []]; R.actor = null; FX.carry(R, s);
  say(R, `${nm(s)} 턴 종료`); R.turn = 1 - s; startTurn(R); }
function settle(R) { let g = 0; while (R.sub && R.sub.fin && !R.eff && !R.q.length && R.phase === 'play' && g++ < 5) { endContact(R); FX.pump(R); } }
function act(R, s, m) { return withCur(R, () => { const e = act0(R, s, m); if (!e) { FX.pump(R); settle(R); if (R.ending && !R.eff && !R.q.length && !R.sub && R.phase === 'play') { doEnd(R); FX.pump(R); settle(R); } } return e; }); }
// 손패 카드 사용 가능 검사(상태를 바꾸지 않음): 서버 검증·행동 목록·봇 이동 생성이 같은 규칙을 쓴다. 가능하면 null
function playCheck(R, s, id) { const P = R.P[s], d = D(R, id);
  const lvUsed = FX.lvOf(R, id); if (lvUsed > fcount(R, s)) return `레벨 ${lvUsed}: FILE 에리어 카드가 부족합니다 (현재 ${fcount(R, s)}장)`;
  if (FX.nameBanned(R, s, id)) return '카드 효과로 인해 이번 턴에는 이 카드명을 사용할 수 없습니다'; if (d.type !== 'char' && FX.pk(R, s, 'noevent')) return '카드 효과로 인해 이번 턴에는 이벤트를 사용할 수 없습니다'; if (!okc(R, s, d, id)) return '내 사건과 색이 맞지 않습니다'; if (!FX.useOk(R, s, id)) return '이 카드의 사용 조건을 만족하지 않습니다'; { const ot = FX.pkVals(R, s, 'onlytrait'); if (d.type === 'char' && ot.length && !ot.every(tr => FX.traitsId(R, id).includes(tr))) return `${ot.join('/')} 특징의 카드만 손패에서 사용할 수 있습니다`; }
  return null; }
function act0(R, s, m) { const P = R.P[s], O = R.P[1 - s];
  if (R.phase === 'over') return '게임이 끝났습니다';
  if (m.a === 'resign') return void win(R, 1 - s, `${nm(s)} 항복`);
  if (R.phase === 'setup') return '상대를 기다리는 중입니다';
  if (R.phase === 'choose') { if (m.a !== 'first') return '선공/후공을 정하는 중입니다'; if (s !== R.chooser) return '상대가 선공/후공을 정하는 중입니다'; if (m.v !== 'first' && m.v !== 'second') return '선공 또는 후공을 선택하세요';
    R.first = m.v === 'first' ? s : 1 - s; say(R, `${nm(s)}이(가) ${m.v === 'first' ? '선공' : '후공'}을 선택했습니다.`); return void beginMull(R); }
  if (R.phase === 'mull') { if (s !== R.mullSeat || m.a !== 'mull') return '내 멀리건 차례가 아닙니다';
    const ids = (m.ids || []).filter(x => P.hand.includes(x)); P.hand = P.hand.filter(x => !ids.includes(x));
    P.deck.push(...ids); shuf(P.deck); ids.forEach(() => P.hand.push(top(R, s))); say(R, `${nm(s)} 멀리건: ${ids.length}장 교체`);
    if (s === R.first) R.mullSeat = 1 - s; else { R.phase = 'play'; R.turn = R.first; R.n = 0; say(R, '게임 시작!'); startTurn(R); } return; }
  if (m.a === 'ans') return FX.answer(R, s, m);
  if (R.eff || R.ending) return '효과 처리 중입니다. 먼저 표시된 선택을 완료하세요.';
  if (R.sub) return subact(R, s, m);
  if (s !== R.turn) return '상대의 턴입니다';
  if (R.fl.hw && !['play', 'skip'].includes(m.a)) return '넥스트 힌트로 얻은 사용 기회를 먼저 처리하세요 (카드 사용 또는 스킵)';
  const pc = R.cards[P.partner];
  switch (m.a) {
    case 'play': { const id = m.id; if (!P.hand.includes(id)) return '손패에 없는 카드입니다'; const d = D(R, id);
      if (!R.fl.hw && (R.fl.played || R.fl.hint)) return R.fl.hint ? '이번 턴에 넥스트 힌트를 했으므로 손패 사용은 불가' : '손패 사용은 턴에 1회입니다';
      { const e = playCheck(R, s, id); if (e) return e; } const lvUsed = FX.lvOf(R, id);
      if (d.type === 'char') { if (P.field.length >= FX.fieldMax(R, s)) { if (!P.field.includes(m.rep)) return '현장이 가득 참 — 스위치할 캐릭터를 선택하세요'; rmChar(R, s, m.rep, 'switch'); say(R, '스위치!'); }
        P.field.push(id); const c = R.cards[id]; c.st = FX.enterSt(R, id); c.sum = 1; c.apm = c.cm = c.lpm = c.lvm = 0; c.tkw = ''; c.tab = []; c.bAp = c.bLp = null; c.lose = ''; FX.mrEnter(R, s, id); FX.noteEnter(R, s, id); }
      const viaHint = !!R.fl.hw; P.hand = P.hand.filter(x => x !== id); say(R, `${nm(s)} 사용: ${D.cn(R, id)}`);
      if (d.type === 'char') { FX.fire(R, 'onplay', id, { by: 'hand' }); FX.fireAlly(R, s, id, { by: 'hand' }); FX.bus(R, 'enter', { s, ent: id, by: viaHint ? 'hint' : 'hand' }); }
      else { FX.queueEvent(R, s, id); FX.bus(R, 'useev', { s, ent: id, by: viaHint ? 'hint' : 'hand' }); }
      if (viaHint) [P.partner, ...P.field].forEach(x => FX.fire(R, 'onhint', x, { by: 'hint', lv: lvUsed, used: id }));
      if (R.fl.hw) R.fl.hw = 0; else R.fl.played = 1; return; }
    case 'skip': R.fl.hw = 0; return;
    case 'hint': if (R.fl.nh) return '이번 턴에는 넥스트 힌트를 할 수 없습니다 (카드 효과)'; if (!P.file.length) return 'FILE 에리어에 카드가 없습니다'; P.hand.push(P.file.pop()); R.fl.hint = 1; R.fl.hw = 1; say(R, `${nm(s)} 넥스트 힌트`); FX.bus(R, 'fileHand', { s, by: 'hint' }); FX.bus(R, 'hint', { s, by: 'hint' }); return;
    case 'assist': if (P.pIn || pc.st !== 'a') return '액티브 파트너만 어시스트할 수 있습니다'; pc.st = 's'; P.pIn = true; say(R, `${nm(s)} 어시스트! (FILE ${fcount(R, s)}장)`);
      if (fcount(R, s) >= 7 && !R.cards[P.kase].solved) FX.setSolved(R, s); return;
    case 'solve': { if (!R.cards[P.kase].solved) return '사건이 해결편이 아닙니다'; if (FX.pk(R, s, 'nosolve')) return '카드 효과로 인해 사건 해결을 할 수 없습니다'; if (P.pIn || pc.st !== 'a') return '파트너가 액티브가 아닙니다';
      const need = +(s === R.first ? D(R, P.kase).lv : D(R, P.kase).lv2) || 0; if (P.evid.length < need) return `증거 부족 (${P.evid.length}/${need})`;
      const alt = FX.winAlt(R, s); if (alt) { for (let i = 0; i < need; i++) { const x = P.evid.pop(); R.cards[x].up = false; P.rem.push(x); } say(R, `증거 은닉! 증거 ${need}장을 리무브`); pc.st = 's'; return win(R, s, '상대는 게임에 패배합니다(증거 은닉)'); }
      pc.st = 's'; return win(R, s, '사건 해결!'); }
    case 'reason': { const who = m.who;
      if (who === 'p') { if (P.pIn || pc.st !== 'a') return '액티브 파트너만 추리할 수 있습니다'; pc.st = 's'; }
      else { const c = R.cards[who]; if (!c || !P.field.includes(who) || c.st !== 'a') return '액티브 캐릭터만 추리할 수 있습니다'; if (FX.hasKwTk(R, who, 'cantreason')) return '이 캐릭터는 추리할 수 없습니다';
        if (c.sum && !tk(R, who).rapid) return '등장한 턴(명승 상태)에는 추리할 수 없습니다 (신속 필요)'; c.st = 's'; FX.bus(R, 'sleepEv', { s, ent: who, by: 'reason' }); }
      say(R, `${nm(s)} 추리 선언`); if (who !== 'p') FX.fire(R, 'onreason', who); FX.bus(R, 'reason', { s, ent: who === 'p' ? P.partner : who }); const ms = O.field.filter(x => R.cards[x].st === 'a' && tk(R, x).mis > 0);
      const go = () => { if (ms.length) R.sub = { type: 'mis', who: 1 - s, rs: who, ms }; else doReason(R, s, who, 0); };
      if (R.q.length || R.eff) R.q.push({ kind: 'cb', s, last: true, fn: go }); else go(); return; }
    case 'action': { const c = R.cards[m.id]; if (!c || !P.field.includes(m.id) || c.st !== 'a') return '액티브 캐릭터만 액션할 수 있습니다';
      const t = tk(R, m.id), k = m.k; if (FX.hasKwTk(R, m.id, 'cantact')) return '이 캐릭터는 액션할 수 없습니다';
      if (c.sum && !(t.rapid || (k === 'char' ? t.asC : t.asE))) return '등장한 턴(명승 상태)에는 액션할 수 없습니다 (신속/돌격 필요)';
      { const md = mustDesig(R, s, m.id); if (md.length && !(k === 'char' && md.includes(m.tid))) return '「必ず指定する」 능력을 가진 캐릭터를 지정해야 합니다'; }
      if (k === 'char') { const tc = R.cards[m.tid]; if (!tc || !O.field.includes(m.tid) || !canDesig(R, m.id, m.tid)) return '슬립/스턴 상태의 상대 캐릭터만 대상입니다'; if (FX.noAct(R, m.tid)) return '카드 효과로 인해 이 캐릭터는 액션의 대상으로 지정할 수 없습니다'; }
      else if (k !== 'case' || !O.evid.length) return '증거가 1장도 없는 사건은 지정할 수 없습니다';
      else if (FX.hasKwTk(R, m.id, 'nocase')) return '이 캐릭터는 사건을 지정해 액션할 수 없습니다';
      if (k === 'char') (R.P[1 - s].field.includes(m.tid) && FX.hasKwTk(R, m.tid, 'mdonce')) && ((R.fl.md1 = R.fl.md1 || {})[m.tid] = 1); c.st = 's'; FX.bus(R, 'sleepEv', { s, ent: m.id, by: 'action' }); R.fl.acted = R.fl.acted || {}; R.fl.acted[m.id] = R.fl.acted[m.id] && R.fl.acted[m.id] !== k ? 'both' : k; FX.fire(R, 'onact', m.id, { k }); FX.bus(R, 'act', { s, ent: m.id, tid: k === 'char' ? m.tid : null, k }); R.sub = { type: 'guard', who: 1 - s, atk: m.id, tk: k, tid: m.tid }; say(R, `${nm(s)} 액션: ${D.cn(R, m.id)} → ${k === 'char' ? D.cn(R, m.tid) : '상대 사건'}`);
      if (t.bullet) { say(R, '불릿: 가드 불가'); return guard(R, null); } return; }
    case 'end': R.ending = 1; P.field.forEach(id => FX.fire(R, 'onend', id)); [P.partner, P.kase, ...P.pa].forEach(id => id != null && FX.fire(R, 'onend', id)); O.field.forEach(id => FX.fire(R, 'onend', id, { gonly: 1, oppEnd: 1 })); [O.partner, O.kase, ...O.pa].forEach(id => id != null && FX.fire(R, 'onend', id, { gonly: 1, oppEnd: 1 })); FX.bus(R, 'turnEnd', { s }); return;
    case 'ability': return FX.declare(R, s, m.id, +m.i);
    default: return '알 수 없는 행동'; } }

// 지금 이 좌석이 각 카드로 "실제로 할 수 있는" 행동 목록 (act0 의 검사와 같은 조건, 상태를 바꾸지 않음). 클라이언트 행동 버튼의 유일한 근거.
// 「必ず指定する」(mustdesig): 상대 현장에 지정 가능한 mustdesig 캐릭터가 있으면 액션은 그 캐릭터 중 하나를 지정해야 한다
const mustDesig = (R, s, atk) => R.P[1 - s].field.filter(x => (FX.hasKwTk(R, x, 'mustdesig') || (FX.hasKwTk(R, x, 'mdonce') && !(R.fl.md1 && R.fl.md1[x]))) && canDesig(R, atk, x) && !FX.noAct(R, x));   // mdonce: 【ターン①】 — 이 턴에 한 번만
// 액티브 상태의 상대 캐릭터를 지정할 수 있는 경우: actactive(모든 액티브 캐릭터) / actset(카드가 세트되어 있는 액티브 캐릭터만)
const canDesig = (R, atk, x) => { const tc = R.cards[x]; return tc.st !== 'a' || FX.hasKwTk(R, atk, 'actactive') || (FX.hasKwTk(R, atk, 'act6up') && FX.lvOf(R, x) >= 6) || (FX.hasKwTk(R, atk, 'act7up') && FX.lvOf(R, x) >= 7) || (FX.hasKwTk(R, atk, 'actset') && (tc.sets || []).length + (tc.fd || []).length > 0); };
// 「ガードできる場合、必ずガードする」(mustguard): 가드 가능한 mustguard 캐릭터가 있으면 반드시 그 캐릭터 중 하나로 가드해야 한다
// 「このキャラがアクションしたとき、相手はガードできる場合、必ずガードする」(forceguard, 공격 쪽 키워드): 가드할 수 있는 캐릭터가 있으면 아무 캐릭터로든 반드시 가드
const mustGuard = (R, s) => { const mg = mustGuard0(R, s); if (mg.length || !(R.sub && R.sub.type === 'guard' && FX.hasKwTk(R, R.sub.atk, 'forceguard'))) return mg;
  return R.P[s].field.filter(x => (R.cards[x].st === 'a' || (R.cards[x].st === 's' && FX.hasKwTk(R, x, 'sleepguard'))) && !FX.hasKwTk(R, x, 'cantguard')); };
const mustGuard0 = (R, s) => R.P[s].field.filter(x => FX.hasKwTk(R, x, 'mustguard') && (R.cards[x].st === 'a' || (R.cards[x].st === 's' && FX.hasKwTk(R, x, 'sleepguard'))) && !FX.hasKwTk(R, x, 'cantguard'));
function actsFor(R, s) { const out = {}; if (R.phase !== 'play' || R.turn !== s || R.sub || R.eff || R.ending || R.fl.hw) return out;
  const P = R.P[s], O = R.P[1 - s], pc = R.cards[P.partner]; const add = (id, a) => { (out[id] = out[id] || []).push(a); };
  const abs = id => FX.abInfo(R, id).filter(a => a.ic === 'declare' && !FX.declareCheck(R, s, id, a.i)).forEach(a => add(id, { k: 'ab', i: a.i, lab: a.lab || (a.txt || '').slice(0, 24) || ('#' + (a.i + 1)) }));
  if (P.partner && pc) { if (!P.pIn && pc.st === 'a') { if (!FX.hasKwTk(R, P.partner, 'cantreason')) add(P.partner, { k: 'reason' }); add(P.partner, { k: 'assist' }); }
    if (R.cards[P.kase] && R.cards[P.kase].solved && !P.pIn && pc.st === 'a' && !FX.pk(R, s, 'nosolve')) { const need = +(s === R.first ? D(R, P.kase).lv : D(R, P.kase).lv2) || 0; if (P.evid.length >= need) add(P.partner, { k: 'solve' }); }
    abs(P.partner); }
  for (const id of P.field) { const c = R.cards[id], t = tk(R, id);
    if (c.st === 'a') { if ((!c.sum || t.rapid) && !FX.hasKwTk(R, id, 'cantreason')) add(id, { k: 'reason' });
      if (!c.sum || t.rapid || t.asC) { const tg = O.field.filter(x => { const tc = R.cards[x]; return canDesig(R, id, x) && !FX.noAct(R, x); }); if (tg.length && !FX.hasKwTk(R, id, 'cantact')) add(id, { k: 'actc', tg: mustDesig(R, s, id).length ? mustDesig(R, s, id) : tg }); }
      if ((!c.sum || t.rapid || t.asE) && !mustDesig(R, s, id).length && O.evid.length && !FX.hasKwTk(R, id, 'nocase') && !FX.hasKwTk(R, id, 'cantact')) add(id, { k: 'actk' }); }
    abs(id); }
  if (P.kase) abs(P.kase); P.pa.forEach(abs);
  for (const id of P.hand) if (FX.abInfo(R, id).some(a => a.ic === 'declare')) abs(id);
  for (const id of [...P.evid, ...P.file]) if (R.cards[id].up && FX.abInfo(R, id).some(a => a.ic === 'declare')) { abs(id); (out[id] || []).forEach(e => { e.z = 1; e.nm = D(R, id).n; }); }   // 표향 증거/FILE 카드의 선언 능력(fromUp)
  return out; }
// 캐릭터에 세트된 카드(sl): 앞면 세트 = 공개 정보 전체, 뒷면(fd) 세트 = 본인에게만 카드 정보, 상대에게는 뒷면(정보 없음). (표시용 직렬화만, 게임 규칙 무관)
// v1.17.1: 뒷면 세트 카드를 고르는 질의(sp)가 열려 있는 동안에는, 그 캐릭터들의 뒷면 세트 카드를 본인에게도 뒷면으로만 내보낸다(hover/우측 상세로 정체가 드러나지 않게). 질의가 끝나면 원래대로.
const hiddenSetIds = (R, s) => { const E = R.eff; if (!E || !E.req || E.req.who !== s || !E.req.sp) return null; const hs = new Set(); for (const e of E.req.sp) { const hc = R.cards[e.h]; if (hc) (hc.fd || []).forEach(y => hs.add(y)); } return hs; };
const withSets = (R, id, owner, viewer, hs) => { const c = R.cards[id], v = co(R, id), fd = c.fd || [], st = c.sets || [];
  if (fd.length || st.length) v.sl = [...fd.map(y => owner === viewer && !(hs && hs.has(y)) ? { ...co(R, y), fd: 1 } : { fd: 1, hidden: 1 }), ...st.map(y => co(R, y))]; return v; };
const logRefs = R => { const st = Math.max(0, R.log.length - 60), o = []; for (let i = st; i < R.log.length; i++) o.push(R.lr && R.lr[i] || 0); return o; };   // v1.17.0: V.log 와 같은 길이의 배열 — 각 줄의 [시작, 끝, 카드 정의 키] 목록 (없으면 0)
const co = (R, id) => { const c = R.cards[id], d = D(R, id); return { id, d: c.d, st: c.st || 'a', apm: ap(R, id) - (+d.ap || 0), lpm: lpOf(R, id) - (+d.lp || 0), sum: c.sum ? 1 : 0, set: (c.sets || []).length + (c.fd || []).length, under: (c.under || []).length, ud: (c.under || []).map(x => R.cards[x].d), up: c.up ? 1 : 0, lvx: FX.lvOf(R, id), u: c.u || {}, kw: (c.tkw || '').trim(), bl: c.blank ? 1 : 0, mg: FX.hasKwTk(R, id, 'mustguard') ? 1 : 0, fg: FX.hasKwTk(R, id, 'forceguard') ? 1 : 0, sg: FX.hasKwTk(R, id, 'sleepguard') ? 1 : 0, ga: FX.grantedAb(R, id) }; };
function effView(R, s) { const E = R.eff; if (!E) return null; const q = E.req;
  if (q.who !== s) return { wait: 1, msg: '상대가 효과를 처리하는 중입니다…' };
  return { kind: q.kind, msg: q.msg, min: q.min, max: q.max, ordered: q.ordered, distinct: q.distinct, labels: q.labels, ord: q.ord ? q.ord.map(o => ({ i: o.i, d: R.cards[o.id] ? R.cards[o.id].d : '', c: co(R, o.id) })) : null, evp: q.evp || null, yes: q.yes, no: q.no, reveal: q.reveal, cards: (q.ids || []).map(x => co(R, x)), sp: q.sp ? q.sp.map(e => e.fd ? { h: e.h, fd: 1, k: e.k, m: e.m } : { h: e.h, fd: 0, c: co(R, e.x) }) : null, sel: q.sel, src: E.it.src != null ? D(R, E.it.src).n : '', srcD: E.it.src != null && R.cards[E.it.src] ? R.cards[E.it.src].d : '', abI: E.it.src != null && E.it.ab ? (D(R, E.it.src).ab || []).indexOf(E.it.ab) : -1, abN: E.it.src != null ? (D(R, E.it.src).ab || []).length : 0, abLab: (E.it.ab && E.it.ab.lab) || '', itK: E.it.kind || '' }; }
const SERVER_VER = (() => { try { return String(require('./package.json').version || ''); } catch (e) { return ''; } })();   // v1.17.35: 클라이언트(index.html)가 서버보다 오래된 파일이면 화면에서 경고
function view(R, s) { const V = { t: 'v', me: s, code: R.code, phase: R.phase, turn: R.turn, n: R.n, sv: SERVER_VER, first: R.first, chooser: R.chooser, chat: (R.chat || []).slice(-100), mull: R.mullSeat, winner: R.winner,
    acts: actsFor(R, s), bot: R.bot ? 1 : 0, rt: !R.bot && R.phase === 'play' && R.turn === s && R.snap && R.snap.n === R.n && R.snap.turn === R.turn ? 1 : 0, botName: R.bot ? (R.bot.name || 'BOT / EXPERT') : '', fl: R.fl, log: R.log.slice(-60), lr: logRefs(R), eff: effView(R, s), both: R.ws.every(Boolean),
    sub: R.sub && { type: R.sub.type, who: R.sub.who, atk: R.sub.atk, def: R.sub.def, tk: R.sub.tk, tid: R.sub.tid, ms: R.sub.ms, mg: R.sub.type === 'guard' ? mustGuard(R, R.sub.who) : undefined }, P: [] };
  const HS = hiddenSetIds(R, s);
  for (const i of [0, 1]) { const P = R.P[i], o = i === s, show = o || R.phase === 'play' || R.phase === 'over';
    V.P.push({ ready: P.ready, deck: P.deck.length, hand: o ? P.hand.map(x => co(R, x)) : P.hand.length, file: P.file.length, evid: P.evid.length,
      rem: P.rem.map(x => co(R, x)), field: P.field.map(x => withSets(R, x, i, s, HS)), pa: P.pa.map(x => co(R, x)), tr: P.tr ? 1 : 0, evUp: P.evid.filter(x => R.cards[x].up).map(x => co(R, x)), evl: P.evid.map(x => R.cards[x].up ? co(R, x) : 0), fil: P.file.map(x => R.cards[x].up ? co(R, x) : 0), fileUp: P.file.filter(x => R.cards[x].up).map(x => co(R, x)),
      partner: P.partner ? (show ? { ...co(R, P.partner), inFile: P.pIn } : { hidden: 1 }) : null,
      kase: P.kase ? (show ? { ...co(R, P.kase), solved: !!R.cards[P.kase].solved } : { hidden: 1 }) : null }); }
  return V; }
// v1.15.0 관전자용 state: 플레이어용 view() 와 별도로 만든다. 일반 플레이어의 view 는 상대 손패를 개수만 담고, 양쪽 손패 전체는 이 함수의 결과에만 들어간다.
// view(R,'spec') 은 어느 자리도 '본인'이 아니므로 뒷면 세트 카드·준비 전 파트너/사건은 비공개로 남고, acts 는 비어 있다(조작 불가).
const SPEC_WAIT = '플레이어가 효과를 처리하는 중입니다…';
function viewSpec(R) { const V = view(R, 'spec'); V.me = 0; V.spec = 1; V.acts = {}; V.rt = 0; V.eff = R.eff ? { wait: 1, msg: SPEC_WAIT } : null; V.nspec = (R.spec || []).length;
  for (const i of [0, 1]) V.P[i].hand = R.P[i].hand.map(x => co(R, x));
  return V; }
const sendSpec = (R, o) => { if (R.spec) for (const w of R.spec) send(w, o); };
// v1.9.0 공개 시스템: 효과가 '공개'를 명시한 경우(fx.js 의 ack + by)에만 reveal 이벤트를 만든다. 공개한 쪽의 상대(to)에게 실제 카드 앞면을 팝업으로 보여준다.
const flushReveal = R => { const ev = R.rv; if (!ev || !ev.length) return; R.rv = [];
  for (const e of ev) { const msg = { t: 'reveal', id: (R.rvSeq = (R.rvSeq || 0) + 1), by: e.by, to: [1 - e.by], ack: e.ack, msg: e.msg, src: e.src != null && R.cards[e.src] ? D(R, e.src).n : '', srcD: e.src != null && R.cards[e.src] ? R.cards[e.src].d : '', cards: e.ids.filter(x => R.cards[x]).map(x => co(R, x)) };
    if (!msg.cards.length) continue; (R.rvLog = R.rvLog || []).push({ id: msg.id, by: msg.by, ids: e.ids.slice() }); R.ws.forEach(w => send(w, msg)); } };   // reveal 팝업은 플레이어에게만 (관전자는 이미 양쪽 손패를 봄)
const bc = R => { flushReveal(R); R.ws.forEach((w, i) => send(w, view(R, i))); if (R.spec && R.spec.length) sendSpec(R, viewSpec(R)); if (R.bot) R.bot.tick(); };
// 사람(WebSocket)과 봇이 같은 검증/실행 경로를 쓴다: 모든 행동은 dispatch → ready/act 를 거친다 (봇 전용 우회 경로 없음)
function dispatch(R, seat, m) {
  if (m.t === 'ready') { const e = withCur(R, () => ready(R, seat, m)); if (!e) { R.ws.forEach(w => send(w, { t: 'defs', defs: R.defs })); sendSpec(R, { t: 'defs', defs: R.defs }); } return e; }
  if (m.t === 'act') return R.bot ? R.bot.apply(seat, m, act) : act(R, seat, m);
  return null; }

// ── 카드 DB: 프로젝트 안의 data/cards.json (상대경로) 이 유일한 원본. 접속한 모든 브라우저에 /api/cards 로 제공한다.
const zlib = require('zlib');
const CARDS_PATH = process.env.CARDS_JSON ? path.resolve(process.env.CARDS_JSON) : path.join(__dirname, 'data', 'cards.json');
let _cards = { key: null, body: null, gz: null, etag: null, count: 0 };
function validateCards(j) {
  if (!j || typeof j !== 'object' || Array.isArray(j)) throw new Error('최상위가 객체가 아닙니다');
  const c = j.cards; if (!c || typeof c !== 'object' || Array.isArray(c)) throw new Error("'cards' 객체가 없습니다");
  const ids = Object.keys(c); if (!ids.length) throw new Error('카드가 0장입니다');
  for (const id of ids) { const d = c[id]; if (!d || typeof d !== 'object' || typeof d.n !== 'string' || !d.type) throw new Error('카드 형식 오류: ' + id); }
  return ids.length;
}
// 파일이 바뀌면(add_new_cards.py 실행 후) 서버 재시작 없이 다음 요청에서 다시 읽는다. 실패하면 예외 → 호출한 쪽이 오류 응답.
function loadCards() {
  const st = fs.statSync(CARDS_PATH), OVP = path.join(path.dirname(CARDS_PATH), 'color_overrides.json'); let ost = null; try { ost = fs.statSync(OVP); } catch (e) {}
  const key = st.mtimeMs + ':' + st.size + ':' + (ost ? ost.mtimeMs + ':' + ost.size : '');
  if (_cards.key === key && _cards.body) return _cards;
  const raw = fs.readFileSync(CARDS_PATH, 'utf8'), j = JSON.parse(raw);
  // v1.8.6: OCR 로 구분이 애매한 카드의 색은 data/color_overrides.json ({"id_0548":"white","id_0930":"blue/black"}) 으로 개별 지정 — cards.json 을 다시 만들어도 유지된다
  if (ost) { try { const ov = JSON.parse(fs.readFileSync(OVP, 'utf8')); for (const [id, col] of Object.entries(ov)) if (j.cards && j.cards[id] && typeof col === 'string') j.cards[id].color = col; } catch (e) { console.error('color_overrides.json 을 읽지 못했습니다:', e.message); } }
  const n = validateCards(j);
  const body = Buffer.from(JSON.stringify({ cards: j.cards }), 'utf8');
  _cards = { key, body, gz: zlib.gzipSync(body), etag: '"' + require('crypto').createHash('md5').update(body).digest('hex') + '"', count: n };
  return _cards;
}
// 서버 안에서 쓰는 파싱된 카드 DB (봇 덱 구성용). 파일이 바뀌면 loadCards 가 새 항목을 만들므로 자동으로 갱신된다.
function cardsObj() { const c = loadCards(); if (!c.obj) c.obj = JSON.parse(c.body.toString('utf8')).cards; return c.obj; }
function serveCards(q, r) {
  let c; try { c = loadCards(); } catch (e) {
    const why = e.code === 'ENOENT' ? 'data/cards.json 파일이 없습니다' : e.message;
    console.error('카드 DB 오류:', why); _cards = { key: null, body: null };
    r.writeHead(503, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    return r.end(JSON.stringify({ error: '카드 DB를 불러올 수 없습니다.', detail: why }));
  }
  const h = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache', 'ETag': c.etag, 'Vary': 'Accept-Encoding', 'X-Card-Count': String(c.count) };
  if (q.headers['if-none-match'] === c.etag) { r.writeHead(304, h); return r.end(); }
  const gz = /\bgzip\b/.test(q.headers['accept-encoding'] || ''); if (gz) h['Content-Encoding'] = 'gzip';
  r.writeHead(200, h); r.end(q.method === 'HEAD' ? undefined : gz ? c.gz : c.body);
}

const IMG_DIR = process.env.CARD_IMAGE_DIR ? path.resolve(process.env.CARD_IMAGE_DIR) : path.join(__dirname, 'CardImage');
const WEB_DIR = process.env.CARD_IMAGE_WEB_DIR ? path.resolve(process.env.CARD_IMAGE_WEB_DIR) : path.join(__dirname, 'CardImageWeb');
// v1.16.0: /CardImageWeb/<ID>.webp = 게임용 최적화본(기본), /CardImage/<파일> = 고해상도 원본(수정 안 함, 읽기만).
// 최적화본이 아직 없으면(새 카드를 추가하고 tools/make_web_images.py 를 아직 안 돌렸을 때 등) 같은 ID 의 원본을 대신 보낸다 → 이미지가 안 뜨는 일이 없다.
function sendImg(q, r, file, name, MIME, cache, fallback) {
  fs.stat(file, (e, st) => {
    if (e || !st.isFile()) { if (fallback) return fallback(); r.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' }); return r.end('image not found'); }
    const etag = '"' + st.size.toString(16) + '-' + Math.floor(st.mtimeMs).toString(16) + '"';
    const h = { 'Content-Type': MIME[path.extname(name).toLowerCase()], 'Content-Length': st.size, 'ETag': etag, 'Last-Modified': st.mtime.toUTCString(), 'Cache-Control': cache };
    if (q.headers['if-none-match'] === etag) { delete h['Content-Length']; r.writeHead(304, h); return r.end(); }
    r.writeHead(200, h); if (q.method === 'HEAD') return r.end();
    fs.createReadStream(file).on('error', () => r.destroy()).pipe(r);
  });
}
// 이미지는 ID 이름 파일이라 거의 안 바뀐다: 하루 동안은 서버에 묻지 않고 브라우저 캐시를 쓰고, 그 뒤엔 ETag 로 304 확인만 한다 (같은 이미지를 다시 내려받지 않음)
const CACHE_WEB = 'public, max-age=86400, stale-while-revalidate=604800', CACHE_ORIG = 'public, max-age=3600';
function serveCardImage(q, r, name, MIME) { return sendImg(q, r, path.join(IMG_DIR, name), name, MIME, CACHE_ORIG); }
function serveWebImage(q, r, name, MIME) {
  return sendImg(q, r, path.join(WEB_DIR, name), name, MIME, CACHE_WEB, () => {
    const stem = name.replace(/\.[^.]+$/, '');
    const tryExt = i => { const ex = ['.jpg', '.png', '.webp'][i]; if (!ex) { r.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' }); return r.end('image not found'); }
      const fn = stem + ex; return sendImg(q, r, path.join(IMG_DIR, fn), fn, MIME, 'no-cache', () => tryExt(i + 1)); };   // 임시 대체본은 캐시하지 않는다(최적화본이 생기면 바로 바뀜)
    tryExt(0); });
}
function main() {
  const { WebSocketServer } = require('ws');
  // UI 정적 자산(카드 뒷면 등): /assets/<파일명> 만 제공 (게임 로직과 무관)
  const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml' };
  const server = http.createServer((q, r) => {
    // Render 등 호스팅의 health check: 게임 상태와 무관, 항상 OK
    if ((q.url || '').split('?')[0] === '/health') { r.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }); return r.end(q.method === 'HEAD' ? undefined : 'OK'); }
    if ((q.url || '').split('?')[0] === '/api/cards') return serveCards(q, r);
    if ((q.url || '').split('?')[0] === '/api/specialists') { // 전문 봇 목록 (registry 에서 자동 생성). 전략 프로필은 내보내지 않는다.
      let body; try { body = { specialists: require('./bot/specialists/registry').list(cardsObj()), problems: require('./bot/specialists/registry').problems() }; } catch (e) { body = { specialists: [], problems: ['전문 봇 목록을 만들 수 없습니다: ' + e.message] }; }
      r.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); return r.end(JSON.stringify(body)); }
    if ((q.url || '').split('?')[0].startsWith('/CardImageWeb/')) {   // v1.16.0: 게임용 최적화 이미지 (cards.json 의 img). 이미지 파일 아니면 404
      const mw = /^\/CardImageWeb\/([A-Za-z0-9_][A-Za-z0-9_.-]*\.(?:jpg|png|webp))$/i.exec((q.url || '').split('?')[0]);
      if (mw && !mw[1].includes('..')) return serveWebImage(q, r, mw[1], MIME);
      r.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' }); return r.end('image not found'); }
    if ((q.url || '').split('?')[0].startsWith('/CardImage/')) {   // v1.14.0: 카드 이미지 원본 파일 (cards.json 의 img = "CardImage/<파일>"). 이 경로 아래는 이미지 파일 아니면 전부 404 (index.html 로 넘기지 않는다)
      const mi = /^\/CardImage\/([A-Za-z0-9_][A-Za-z0-9_.-]*\.(?:jpg|png|webp))$/i.exec((q.url || '').split('?')[0]);
      if (mi && !mi[1].includes('..')) return serveCardImage(q, r, mi[1], MIME);
      r.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' }); return r.end('image not found'); }
    const m = /^\/assets\/([\w.-]+)$/.exec((q.url || '').split('?')[0]);
    if (m && MIME[path.extname(m[1]).toLowerCase()]) return fs.readFile(path.join(__dirname, 'assets', m[1]), (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'Content-Type': MIME[path.extname(m[1]).toLowerCase()], 'Cache-Control': 'public, max-age=86400' }); r.end(d); });
    fs.readFile(path.join(__dirname, 'index.html'), (e, d) => { if (e) { r.writeHead(500); return r.end('index.html 을 읽을 수 없습니다'); } r.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' }); r.end(d); }); });
  const wss = new WebSocketServer({ server, maxPayload: 30e6 });
  wss.on('connection', ws => { ws.isAlive = true; ws.on('pong', () => { ws.isAlive = true; }); ws.on('error', () => {}); }); // 유휴 연결 유지용 ping (프록시가 조용한 WebSocket 을 끊는 것을 방지)
  // ── 연결 끊김 처리 (v1.5.1) ── 끊기면 바로 패배 처리하지 않고 GRACE 동안 같은 자리로 재접속(resume)을 기다린다. (RECONNECT_GRACE_MS=0 이면 예전처럼 즉시 종료)
  const GRACE = process.env.RECONNECT_GRACE_MS != null ? +process.env.RECONNECT_GRACE_MS : 60000;
  const seatTok = (R, seat, ws) => { R.tok = R.tok || [null, null]; R.tok[seat] = require('crypto').randomBytes(12).toString('hex'); send(ws, { t: 'joined', code: R.code, seat, token: R.tok[seat] }); };
  // v1.15.0 관전자: R.spec = 관전 소켓 배열 (플레이어 슬롯 R.ws[0..1] 과 완전히 분리). 관전 소켓은 ws.spec=true, ws.seat 없음.
  const MAX_SPEC = 30;
  const closeSpec = (R, msg) => { const L = R.spec || []; R.spec = []; for (const w of L) { w.R = null; w.spec = false; send(w, { t: 'left', msg }); } };
  const dropSpec = (R, ws) => { if (R.spec) R.spec = R.spec.filter(w => w !== ws); ws.R = null; ws.spec = false; };
  const endSeat = (R, seat) => { if (R.gt && R.gt[seat]) { clearTimeout(R.gt[seat]); R.gt[seat] = null; } if (R.ws[seat]) return;   // 그 사이 돌아왔으면 종료하지 않음
    R.ws[seat] = null; if (R.bot) { R.bot.stop(); R.ws[1 - seat] = null; }
    if (R.phase === 'play' || R.phase === 'mull' || R.phase === 'choose') { R.phase = 'over'; R.winner = 1 - seat; say(R, '상대가 나가서 게임이 종료되었습니다.'); }
    bc(R); if (!R.ws[0] && !R.ws[1]) { delete rooms[R.code]; closeSpec(R, '방이 종료되었습니다.'); } };
  const resume = (ws, m) => { const R = rooms[cl(m.code, 8).toUpperCase().trim()], seat = +m.seat;
    if (!R || (seat !== 0 && seat !== 1) || !R.tok || !m.token || R.tok[seat] !== m.token) return send(ws, { t: 'resumeFail', msg: '이전 방을 찾을 수 없습니다 (서버가 재시작되었거나 재접속 시간이 지났습니다). 로비로 돌아갑니다.' });
    if (R.bot && seat !== 0) return send(ws, { t: 'resumeFail', msg: '잘못된 재접속 요청입니다.' });
    const old = R.ws[seat]; if (old && old !== ws) { old.R = null; try { old.terminate(); } catch (e) {} }   // 서버가 아직 끊김을 모르는 죽은 소켓이면 정리
    if (R.gt && R.gt[seat]) { clearTimeout(R.gt[seat]); R.gt[seat] = null; }
    R.ws[seat] = ws; ws.R = R; ws.seat = seat; say(R, R.phase === 'over' ? '재접속했습니다.' : '상대가 재접속했습니다.'); send(ws, { t: 'joined', code: R.code, seat, token: R.tok[seat] }); send(ws, { t: 'defs', defs: R.defs }); bc(R); };
  wss.on('connection', ws => ws.on('message', raw => { let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object') return;
    // 관전자 소켓은 완전한 읽기 전용: 나가기(leaveRoom) 외의 모든 메시지(act·ready·restartGame·restartTurn·leaveBot·botlog·create·join·resume…)를 서버가 거부한다.
    // v1.17.34 채팅: 플레이어와 관전자 모두 보낼 수 있다(봇전 제외). 길이·속도 제한, 최근 100개만 보관.
    if (m.t === 'chat') { const R = ws.R; if (!R || R.bot) return send(ws, { t: 'err', msg: '채팅을 사용할 수 없는 방입니다.' });
      const txt = String(m.text == null ? '' : m.text).replace(/[\u0000-\u001f\u007f]+/g, ' ').trim().slice(0, 200); if (!txt) return;
      const now = Date.now(); ws.cts = (ws.cts || []).filter(t => now - t < 4000); if (ws.cts.length >= 5) return send(ws, { t: 'err', msg: '채팅을 너무 빠르게 보내고 있습니다. 잠시 후 다시 시도하세요.' }); ws.cts.push(now);
      if (ws.spec && !ws.sn) ws.sn = R.specSeq = (R.specSeq || 0) + 1;
      const e = { id: R.chatSeq = (R.chatSeq || 0) + 1, w: ws.spec ? 2 : ws.seat, n: ws.spec ? '관전자 ' + ws.sn : '플레이어 ' + (ws.seat + 1), t: txt }; (R.chat = R.chat || []).push(e); if (R.chat.length > 100) R.chat.splice(0, R.chat.length - 100);
      R.ws.forEach(w => send(w, { t: 'chat', m: e })); sendSpec(R, { t: 'chat', m: e }); return; }
    if (ws.spec) { if (m.t === 'leaveRoom') { if (ws.R) dropSpec(ws.R, ws); return send(ws, { t: 'left' }); } return send(ws, { t: 'err', msg: '관전자는 조작할 수 없습니다.' }); }
    if (m.t === 'spectate') { if (ws.R) return send(ws, { t: 'err', msg: '이미 방에 들어가 있습니다.' });
      const R = rooms[cl(m.code, 8).toUpperCase().trim()];
      if (!R) return send(ws, { t: 'err', msg: '없는 방 코드입니다.' });
      if (R.noSpec) return send(ws, { t: 'err', msg: '이 방은 관전이 허용되지 않습니다.' });   // 서버 검증: 클라이언트 UI 와 무관
      if (R.bot) return send(ws, { t: 'err', msg: '봇 대전·연습 방은 관전할 수 없습니다.' });
      R.spec = R.spec || []; if (R.spec.length >= MAX_SPEC) return send(ws, { t: 'err', msg: '관전 인원이 가득 찼습니다.' });
      R.spec.push(ws); ws.R = R; ws.spec = true; ws.seat = null;
      send(ws, { t: 'spectating', code: R.code }); send(ws, { t: 'defs', defs: R.defs }); send(ws, viewSpec(R));
      return bc(R); }   // 관전자 수(nspec) 갱신용 — 게임 상태는 바뀌지 않음
    if (m.t === 'create') { let c; do { c = Math.random().toString(36).slice(2, 6).toUpperCase(); } while (rooms[c]);
      const R = rooms[c] = mkR(c); if (m.noSpec === true) R.noSpec = true; R.rng = (Math.random() * 4294967296) >>> 0; R.ws[0] = ws; ws.R = R; ws.seat = 0; seatTok(R, 0, ws); return bc(R); }
    if (m.t === 'resume') return resume(ws, m);
    if (m.t === 'join') { const R = rooms[cl(m.code, 8).toUpperCase().trim()];
      if (!R) return send(ws, { t: 'err', msg: '없는 방 코드입니다.' }); if (R.ws[1]) return send(ws, { t: 'err', msg: '방이 가득 찼습니다.' });
      R.ws[1] = ws; ws.R = R; ws.seat = 1; seatTok(R, 1, ws); say(R, '게스트가 입장했습니다.'); send(ws, { t: 'defs', defs: R.defs }); return bc(R); }
    if (m.t === 'createBot') { if (ws.R) return; try { const R = require('./bot/controller').createRoom({ rooms, mkR, ready, dispatch, loadCards: () => ({ cards: cardsObj() }), say, cl, ws, m, send, bc }); ws.R = R; ws.seat = 0; seatTok(R, 0, ws); return bc(R); } catch (err) { return send(ws, { t: 'err', msg: '봇 대전을 시작할 수 없습니다: ' + (err && err.message || err) }); } }
    if (m.t === 'leaveRoom') { const R0 = ws.R; if (R0 && !R0.bot) { const seat = ws.seat; if (R0.ws[seat] === ws) R0.ws[seat] = null; endSeat(R0, seat); ws.R = null; ws.seat = null; send(ws, { t: 'left' }); } else send(ws, { t: 'left' }); return; }
    if (m.t === 'restartGame') { const R0 = ws.R; if (!R0 || R0.bot) return send(ws, { t: 'err', msg: '사람 대 사람 게임에서만 사용할 수 있습니다.' }); resetRoom(R0, ws.seat);
      R0.ws.forEach((w, i) => { if (!w) return; send(w, { t: 'reset', kind: 'game', by: ws.seat }); if (R0.tok && R0.tok[i]) send(w, { t: 'joined', code: R0.code, seat: i, token: R0.tok[i] }); send(w, { t: 'defs', defs: {} }); }); sendSpec(R0, { t: 'reset', kind: 'game', by: -1 }); sendSpec(R0, { t: 'defs', defs: {} }); return bc(R0); }
    if (m.t === 'restartTurn') { const R0 = ws.R; if (!R0) return; const e0 = turnRestart(R0, ws.seat); if (e0) return send(ws, { t: 'err', msg: e0 }); R0.ws.forEach(w => send(w, { t: 'reset', kind: 'turn', by: ws.seat })); sendSpec(R0, { t: 'reset', kind: 'turn', by: ws.seat }); return bc(R0); }
    if (m.t === 'leaveBot') { const R0 = ws.R; if (R0 && R0.bot) { R0.bot.stop(); delete rooms[R0.code]; ws.R = null; send(ws, { t: 'left' }); } return; }
    const R = ws.R; if (!R) return; let e;
    if (m.t === 'botlog') return send(ws, R.bot ? R.bot.logMsg() : { t: 'botlog', err: '봇 대전이 아닙니다' });
    e = dispatch(R, ws.seat, m);
    if (e) send(ws, { t: 'err', msg: e }); bc(R); }).on('close', () => { const R = ws.R; if (ws.spec) { if (R) { dropSpec(R, ws); bc(R); } return; }   // 관전자 이탈: 게임·플레이어 연결·방 수명에 영향 없음 (관전자 수만 갱신)
      if (!R || R.ws[ws.seat] !== ws) return;   // 이미 새 소켓으로 교체된(resume) 자리의 옛 소켓 close 는 무시
      const seat = ws.seat; R.ws[seat] = null;
      if (GRACE <= 0 || R.phase === 'over' || !R.ws[1 - seat]) return endSeat(R, seat);   // 유예 없음 / 이미 끝난 방 / 상대도 없는 방
      R.gt = R.gt || []; clearTimeout(R.gt[seat]); R.gt[seat] = setTimeout(() => endSeat(R, seat), GRACE); R.gt[seat].unref && R.gt[seat].unref();
      if (!R.bot) say(R, '⚠ 상대의 연결이 끊어졌습니다. 재접속을 기다리는 중입니다…'); bc(R); }));
  const hb = setInterval(() => { wss.clients.forEach(w => { if (w.readyState !== 1) return; if (!w.isAlive) return w.terminate(); w.isAlive = false; try { w.ping(); } catch (e) {} }); }, +process.env.WS_PING_MS || 25000); hb.unref();
  process.on('uncaughtException', e => console.error('uncaught:', e && e.stack || e));
  const stop = () => { clearInterval(hb); wss.clients.forEach(w => w.close()); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
  // Render 가 주는 PORT 를 사용, 없으면 3000. 주소를 지정하지 않으므로 모든 네트워크 인터페이스(외부 접속 포함)에서 받는다.
  const PORT = Number(process.env.PORT) || 3000;
  server.listen(PORT, () => console.log(`listening on port ${PORT}`));
}
const sysRun = (R, f) => withCur(R, () => { const r = f(); FX.pump(R); settle(R); return r; });   // v1.12.0: 연습 모드(Training AI) 전용 시스템 처리 — 난수 컨텍스트 + 효과 큐 처리
module.exports = { viewSpec, sysRun, turnRestart, resetRoom, snapTake, flushReveal, bc, actsFor, playCheck, mkR, ready, act, view, FX, ap, lpOf, tk, loadCards, validateCards, dispatch, D, tok, fcount, okc, mustGuard, mustDesig, cols };
if (require.main === module) main();
